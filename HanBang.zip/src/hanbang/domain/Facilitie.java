package hanbang.domain;

public class Facilitie {

	private int facilitieId;
	private int extraInfoId;
	private String facilitie;

	public int getFacilitieId() {
		return facilitieId;
	}

	public void setFacilitieId(int facilitieId) {
		this.facilitieId = facilitieId;
	}

	public int getExtraInfoId() {
		return extraInfoId;
	}

	public void setExtraInfoId(int extraInfoId) {
		this.extraInfoId = extraInfoId;
	}

	public String getFacilitie() {
		return facilitie;
	}

	public void setFacilitie(String facilitie) {
		this.facilitie = facilitie;
	}

}
