package hanbang.domain;

public class InterestShareHouse {
	private int shareHouseId;
	private String memberId;
	
	
	public int getShareHouseId() {
		return shareHouseId;
	}
	public void setShareHouseId(int shareHouseId) {
		this.shareHouseId = shareHouseId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

}
